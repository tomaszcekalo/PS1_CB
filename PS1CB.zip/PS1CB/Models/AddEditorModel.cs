﻿namespace PS1CB.Models
{
    public class AddEditorModel
    {
        public int MessageId { get; internal set; }
        public string EditorName { get; internal set; }
    }
}
